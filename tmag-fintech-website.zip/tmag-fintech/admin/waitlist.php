<?php
/**
 * TMAG Fintech — Waitlist Admin Panel
 * Access: /admin/waitlist.php
 * IMPORTANT: Protect this with HTTP auth or move outside webroot in production.
 */

// ── Simple password protection ──────────────
$ADMIN_PASS = 'tmag_admin_2026'; // Change this!
session_start();

if ($_POST['pass'] ?? '' === $ADMIN_PASS) {
    $_SESSION['tmag_admin'] = true;
}
if (!($_SESSION['tmag_admin'] ?? false)) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $error = 'Incorrect password.';
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>TMAG Admin</title>
      <style>
        body { background:#080808; color:#f2f2f2; font-family:'DM Sans',sans-serif; display:flex; align-items:center; justify-content:center; min-height:100vh; margin:0; }
        .box { background:#141414; border:0.5px solid #222; border-radius:12px; padding:2rem; width:320px; }
        h2 { font-size:1.2rem; margin-bottom:1.5rem; }
        input { width:100%; padding:10px 14px; background:#1a1a1a; border:0.5px solid #2e2e2e; border-radius:8px; color:#f2f2f2; font-size:14px; margin-bottom:1rem; box-sizing:border-box; }
        button { width:100%; padding:11px; background:#f2f2f2; color:#080808; border:none; border-radius:8px; font-size:14px; font-weight:500; cursor:pointer; }
        .err { color:#e03c3c; font-size:13px; margin-bottom:1rem; }
      </style>
    </head>
    <body>
      <div class="box">
        <h2>TMAG Admin</h2>
        <?php if (!empty($error)) echo '<p class="err">' . htmlspecialchars($error) . '</p>'; ?>
        <form method="POST">
          <input type="password" name="pass" placeholder="Admin password" autofocus />
          <button type="submit">Sign in</button>
        </form>
      </div>
    </body>
    </html>
    <?php
    exit;
}

// ── Load data ────────────────────────────────
$db_path = __DIR__ . '/../db/tmag.db';
$entries = [];
$total   = 0;

if (file_exists($db_path)) {
    $db = new PDO('sqlite:' . $db_path);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $entries = $db->query("SELECT * FROM waitlist ORDER BY created DESC")->fetchAll(PDO::FETCH_ASSOC);
    $total   = count($entries);
}

// ── Export CSV ──────────────────────────────
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="tmag-waitlist-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['ID', 'Name', 'Email', 'Role', 'Signed Up']);
    foreach ($entries as $row) {
        fputcsv($out, [$row['id'], $row['name'], $row['email'], $row['role'], $row['created']]);
    }
    fclose($out);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TMAG Fintech — Waitlist Admin</title>
  <style>
    * { box-sizing:border-box; margin:0; padding:0; }
    body { background:#080808; color:#f2f2f2; font-family:'DM Sans',sans-serif; font-size:14px; }
    .topbar { background:#0f0f0f; border-bottom:0.5px solid #222; padding:1rem 2rem; display:flex; justify-content:space-between; align-items:center; }
    .topbar h1 { font-size:1.1rem; font-weight:500; }
    .topbar span { color:#666; font-size:12px; }
    .container { max-width:1100px; margin:0 auto; padding:2rem 1.5rem; }
    .stats { display:grid; grid-template-columns:repeat(3,1fr); gap:1rem; margin-bottom:2rem; }
    .stat { background:#141414; border:0.5px solid #222; border-radius:10px; padding:1.25rem; }
    .stat-num { font-size:2rem; font-weight:500; color:#f2f2f2; }
    .stat-label { font-size:12px; color:#666; margin-top:4px; }
    .actions { display:flex; gap:10px; margin-bottom:1.5rem; justify-content:flex-end; }
    .btn { padding:8px 18px; border-radius:8px; font-size:13px; cursor:pointer; text-decoration:none; }
    .btn-white { background:#f2f2f2; color:#080808; border:none; }
    .btn-outline { background:transparent; border:0.5px solid #2e2e2e; color:#aaa; }
    table { width:100%; border-collapse:collapse; background:#141414; border-radius:10px; overflow:hidden; }
    th { text-align:left; padding:12px 16px; font-size:11px; color:#666; text-transform:uppercase; letter-spacing:0.08em; border-bottom:0.5px solid #222; font-weight:400; }
    td { padding:12px 16px; border-bottom:0.5px solid #1a1a1a; font-size:13px; color:#aaa; }
    tr:hover td { background:#1a1a1a; }
    tr:last-child td { border-bottom:none; }
    .role-badge { display:inline-block; padding:2px 8px; border-radius:4px; background:#1a1a1a; border:0.5px solid #2e2e2e; font-size:11px; color:#666; }
    .empty { text-align:center; padding:3rem; color:#444; }
    @media(max-width:600px) { .stats{grid-template-columns:1fr;} td,th{padding:10px 12px;} }
  </style>
</head>
<body>
<div class="topbar">
  <h1>TMAG Fintech · Waitlist Admin</h1>
  <span><?= date('D, d M Y') ?></span>
</div>
<div class="container">
  <div class="stats">
    <div class="stat"><div class="stat-num"><?= $total ?></div><div class="stat-label">Total signups</div></div>
    <div class="stat"><div class="stat-num"><?= count(array_filter($entries, fn($r) => strtotime($r['created']) > strtotime('-7 days'))) ?></div><div class="stat-label">Last 7 days</div></div>
    <div class="stat"><div class="stat-num"><?= count(array_filter($entries, fn($r) => strtotime($r['created']) > strtotime('-24 hours'))) ?></div><div class="stat-label">Last 24 hours</div></div>
  </div>

  <div class="actions">
    <a href="?export=csv" class="btn btn-white">Export CSV</a>
    <a href="?logout=1" class="btn btn-outline" onclick="<?php if(isset($_GET['logout'])){session_destroy();}?>">Sign out</a>
  </div>

  <?php if (empty($entries)): ?>
    <div class="empty">No signups yet. Share the waitlist link!</div>
  <?php else: ?>
  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Name</th>
        <th>Email</th>
        <th>Role</th>
        <th>Signed Up</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($entries as $i => $row): ?>
      <tr>
        <td><?= $total - $i ?></td>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td><?= htmlspecialchars($row['email']) ?></td>
        <td><span class="role-badge"><?= htmlspecialchars($row['role'] ?: '—') ?></span></td>
        <td><?= date('d M Y, H:i', strtotime($row['created'])) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>
</div>
</body>
</html>
